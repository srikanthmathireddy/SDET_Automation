package StepDefinitions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.lang.module.Configuration;
import java.util.List;
import java.util.Map;

import io.restassured.response.ResponseBody;
import org.junit.Assert;
import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class Rest_Assured_Steps
{
    @Given("^Navigate to Booking Website and Retreive the Booking Website response and assert the response$")
    public void Retreive_Booking_IDS()
    {
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
        Response Response = given()
                .contentType(ContentType.JSON)
                .when()
                .get("/booking")
                .then()
                .extract().response();

        ResponseBody body = Response.getBody();
        System.out.println("Booking IDS's "+ body.asString());
        Assertions.assertEquals(200, Response.statusCode());
    }

}
