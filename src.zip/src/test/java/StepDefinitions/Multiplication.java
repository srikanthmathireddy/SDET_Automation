package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.io.IOException;

public class Multiplication

{
    int a;
    int b;
    int c;
    @Given("^Multiply Two Nos$")
    public void Multiply() throws InterruptedException, IOException
    {

          int n=10;
          int sum=0;
          for (int x=1;x<=n;x++)
          {
              sum=sum+x;
              System.out.println("Output Value:"+sum);
          }
           //System.out.println("Output Value:"+sum);
       }
    @Then("^Output the Result$")
    public void Output() throws InterruptedException, IOException
    {
        c=a*b;
       // System.out.println("Output Value:"+c);
    }
}
